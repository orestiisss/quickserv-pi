
let cart = [];

function addToCart(item) {
  cart.push(item);
  renderCart();
}

function renderCart() {
  const ul = document.getElementById('cart');
  ul.innerHTML = '';
  cart.forEach((item, i) => {
    const li = document.createElement('li');
    li.textContent = item;
    ul.appendChild(li);
  });
}

function checkout() {
  if (cart.length === 0) return alert("Cart is empty!");
  alert("This would redirect to Pi payment system (testnet).");
}
