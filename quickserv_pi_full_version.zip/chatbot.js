
document.getElementById('user-input').addEventListener('keypress', function (e) {
  if (e.key === 'Enter') {
    const input = e.target.value.trim();
    if (!input) return;
    const bot = document.getElementById('chatbot');
    bot.innerHTML += '<p><strong>You:</strong> ' + input + '</p>';
    bot.innerHTML += '<p><strong>Bot:</strong> ' + generateReply(input) + '</p>';
    bot.scrollTop = bot.scrollHeight;
    e.target.value = '';
  }
});

function generateReply(message) {
  const lower = message.toLowerCase();
  if (lower.includes("order")) return "You can add items to your cart above and checkout.";
  if (lower.includes("hello") || lower.includes("hi")) return "Hi there! I'm here to help with your order.";
  if (lower.includes("time")) return "Orders usually arrive within 30–45 minutes.";
  return "I'm not sure, but I'm learning more every day!";
}
