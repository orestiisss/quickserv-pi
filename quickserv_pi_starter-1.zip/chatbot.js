
document.getElementById('user-input').addEventListener('keypress', function (e) {
  if (e.key === 'Enter') {
    const input = e.target.value;
    const bot = document.getElementById('chatbot');
    const userMsg = document.createElement('p');
    userMsg.innerHTML = '<strong>You:</strong> ' + input;
    bot.appendChild(userMsg);

    // Mock reply from GPT (can be replaced with actual API call)
    const reply = document.createElement('p');
    reply.innerHTML = '<strong>Bot:</strong> Thanks for your message! (This is a demo response.)';
    bot.appendChild(reply);
    bot.scrollTop = bot.scrollHeight;
    e.target.value = '';
  }
});
